INSERT INTO Course(CourseId,Title,Fees,Description,Trainer,Start_date) values(1,'CSE',4000.0,'Computer Science and Engineering','Ashok Kumar','2021-08-22');
INSERT INTO Course(CourseId,Title,Fees,Description,Trainer,Start_date) values(2,'ME',3000.0,'Mechanical Engineering','Aditya','2021-08-20');
INSERT INTO Course(CourseId,Title,Fees,Description,Trainer,Start_date) values(3,'IT',5000.0,'Informtion Technology','Arun Sharma','2021-08-15');
INSERT INTO Student(EnrollmentId,StudentId,CourseId) values(2,5002,1002);
INSERT INTO Trainer(TrainerId,Password) values(1,'sam123');
