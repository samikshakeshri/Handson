DROP TABLE Course IF EXISTS;
CREATE TABLE Course(CourseId int, Title VARCHAR(200), Fees float, Description VARCHAR(MAX), Trainer VARCHAR, Start_date date);
DROP TABLE Student IF EXISTS;
CREATE TABLE Student(EnrollmentId int, StudentId int, CourseId int);
DROP TABLE Trainer IF EXISTS;
CREATE TABLE Trainer(TrainerId int, Password char(10));